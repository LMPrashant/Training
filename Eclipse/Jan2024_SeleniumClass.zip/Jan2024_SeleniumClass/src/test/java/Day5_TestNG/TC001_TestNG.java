package Day5_TestNG;

import org.testng.annotations.Test;

public class TC001_TestNG {

	@Test
	public void logintest() {
		System.out.println("Hello");
	}
	
}


