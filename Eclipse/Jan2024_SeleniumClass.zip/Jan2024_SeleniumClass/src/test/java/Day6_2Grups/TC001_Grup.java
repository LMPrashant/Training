package Day6_2Grups;

import org.testng.annotations.Test;

public class TC001_Grup {
  @Test(groups = "sanity")
  public void f() {
	  System.out.println("This u know");
  }
}
