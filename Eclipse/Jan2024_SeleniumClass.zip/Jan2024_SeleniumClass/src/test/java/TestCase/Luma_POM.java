package TestCase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Luma_POM {

WebDriver driver;
	
	By fname = By.name("firstname");
	By lname = By.name("lastname");
	By email = By.name("email");
	By pword = By.name("password");
	By pword1 = By.name("password_confirmation");
	By loginbtn = By.xpath("//button[@type='submit']");
	//By dashboard = By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[1]");
	

	public boolean verifyusername()
	{
		boolean isusername_displayed=driver.findElement(lname).isDisplayed();
		return isusername_displayed;
	}
	public boolean verifypassword()
	{
		boolean ispassword_displayed=driver.findElement(pword).isDisplayed();
		return ispassword_displayed;
	}
	
	public void enterfname(String userfname) {
		driver.findElement(fname).sendKeys(userfname);
	}
	
	public void enterlname(String userlname) {
		driver.findElement(lname).sendKeys(userlname);
	}
	
	public void enteremail(String email1) {
		driver.findElement(email).sendKeys(email1);
	}
	
	public void enterpword(String password) {
		driver.findElement(pword1).sendKeys(password);
	}
	
	public void clicklogin() {
		driver.findElement(loginbtn).click();
	}
	
//	public boolean verifylogin()
//	{boolean isdashboard_displayed;
//		try
//		{
//		 isdashboard_displayed=driver.findElement(dashboard).isDisplayed();
//		}
//		catch(Exception e)
//		{
//			isdashboard_displayed=false;
//		}
//		
//		return isdashboard_displayed;
//	}
}
